./hellminer -c stratum+ssl://na.luckpool.net:3958 -u  RL5Bce95KspuxP8carp47NU3fBnZ2cpbnT -p x --cpu 32
